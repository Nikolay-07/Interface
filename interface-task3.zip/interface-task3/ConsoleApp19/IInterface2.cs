﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp19
{
    interface IInterface2 : IInterface1
    {
        void Method2();
    }
}
