﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp21
{
    interface ISwitchable
    {
        void Vkl();
        void Vukl();
    }
}
